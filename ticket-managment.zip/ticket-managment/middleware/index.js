const { validateCreateTicket, validateUpdateTicket } = require('../route/validation');

router.post('/', validateCreateTicket, ticketController.createTicket);
router.put('/:id', validateUpdateTicket, ticketController.updateTicketById);
